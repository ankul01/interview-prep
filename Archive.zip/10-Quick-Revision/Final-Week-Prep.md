# Final Week Prep

Quick revision checklist and key points for the last week before interviews.
