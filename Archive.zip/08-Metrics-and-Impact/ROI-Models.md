# ROI Models

Frameworks for calculating return on investment for engineering initiatives.
