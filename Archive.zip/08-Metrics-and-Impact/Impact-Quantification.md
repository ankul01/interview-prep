# Impact Quantification

How to measure and articulate the impact of your engineering work.
