# Working Backwards from the Customer

Behavioral questions focused on customer-centric thinking, removing friction, and building scalable solutions that start from the customer's pain point.

---

## Table of Contents

| # | Question | Theme |
|---|---------|-------|
| 1 | [Tell me about a time you took a complex manual process and turned it into a scalable technical platform.](#q1-manual-process-to-scalable-platform) | Platform Thinking, Customer Impact |
| 2 | [Add next question here](#q2-placeholder) | — |

---

## Q1: Manual Process to Scalable Platform

> **Question:** "Tell me about a time you took a complex manual process and turned it into a scalable technical platform. What was the impact on the customer?"

### Situation — The Strategic Context

As a leader in the Embedded Insurance domain, I realized our growth was capped — not by market demand, but by internal friction.

Onboarding a new partner required:
- 7–8 pages of complex data collection (IRDAI product types, multi-attribute pricing logic, eligibility rules)
- Manual DB scripts for each configuration
- Custom HTML templates for Certificates of Insurance (COI)
- **~1 week of engineering effort per partner**

I diagnosed that this "custom-code per partner" model was:
- A **scalability bottleneck** — linear effort for each new partner
- A **revenue risk** — slow onboarding meant lost deals
- **Highly engineering-dependent** — business teams couldn't move without dev support
- **Operationally fragile** — manual scripts with no audit trail

**The real constraint was not demand — it was process inefficiency.**

### Task — Stakeholder Alignment & Architecture

This wasn't just a technical problem — it was an alignment problem.

I brought together cross-functional stakeholders: **Actuary, Claims, Underwriting, and Product** — teams that had never jointly defined a standardized onboarding framework.

**Goal:** Standardize fragmented, team-specific requirements into a single scalable platform.

I proposed and drove the architecture for **Ackcelerator**, which included:
- A **Workflow Manager** to orchestrate the onboarding lifecycle
- A **Maker–Checker framework** for compliance and audit control
- A **UI-driven configuration engine** replacing manual DB scripts
- A **modular architecture** handling 80% of standard use cases out-of-the-box

**Key design principle:** Remove Engineering from the critical path — without compromising compliance or risk controls.

### Action — What I Did

- Led the cross-functional discovery and alignment across 4 teams
- Defined the product vision, architecture, and rollout strategy
- Made deliberate tradeoffs: built for the 80% standard path first, kept escape hatches for edge cases
- Ensured compliance requirements (maker–checker, auditability) were first-class citizens in the design

### Result — Measurable Outcomes

| Metric | Before | After |
|---|---|---|
| Partner onboarding time | ~1 week | ~2 hours |
| Engineering intervention for standard integrations | Required every time | Zero |
| Engineering bandwidth | Spent on repetitive config | Redirected to platform innovation |

**Business impact:**
- Enabled major launches: **HDB, Credit Life**
- Contributed to a **₹400+ Cr annualized portfolio**
- Fundamentally changed the operating model from project-based to platform-based

### What Senior Interviewers Will Evaluate

**1. Stakeholder Negotiation**
- How you convinced Actuary and Compliance teams that a self-service UI could replace manual DB scripts
- How risk and governance were preserved (maker–checker, audit trails)
- What pushback you faced and how you handled it

> In fintech/payments companies (e.g., PayPal), **Risk & Compliance credibility** is a key evaluation signal.

**2. The "Zero Intervention" Goal**
- You didn't just make the process *faster* — you **removed Engineering from the critical path** entirely
- You **changed the operating model** from reactive (ticket-driven) to self-service
- This is what distinguishes senior-level thinking from optimization work

**3. Scalability Mindset**
- The solution was **reusable across LOBs** (Auto, Health, Credit Life, etc.)
- It was designed as a **platform**, not a one-off project
- The 80/20 modular approach allowed rapid extension without rearchitecting

### Red Flags to Avoid

| Mistake | Why It Hurts | What to Do Instead |
|---|---|---|
| Over-focusing on tech details (DB scripts, APIs) | Sounds like an IC, not a leader | Lead with **customer pain, revenue risk, and business outcome** |
| Ignoring compliance controls | Self-service in regulated domains raises red flags | Always mention **maker–checker, auditability, and operational rigor** |
| Vague impact numbers | Undermines credibility | Use specific metrics: **98% reduction, ₹400+ Cr portfolio, zero engineering intervention** |

### Key Takeaways

1. **Identified** a scalability bottleneck hiding behind a manual onboarding process
2. **Aligned** cross-functional teams (Actuary, Claims, Underwriting, Product) around a shared platform vision
3. **Architected** a reusable, compliance-first platform (Ackcelerator)
4. **Delivered** 98% reduction in onboarding time and zero engineering dependency for standard flows
5. **Unlocked** business growth — enabling ₹400+ Cr portfolio expansion

---

## Q2: Placeholder

> **Question:** *Add your next question here.*

<!-- Copy the STAR template below to get started:

### Situation — ...
### Task — ...
### Action — ...
### Result — ...
### What Interviewers Will Evaluate
### Red Flags to Avoid
### Key Takeaways
-->
