# Tradeoff Matrix

A structured way to evaluate and communicate engineering tradeoffs.
